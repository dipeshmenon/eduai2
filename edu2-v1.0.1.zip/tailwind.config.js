module.exports = {
  mode: "jit",
  content: [
    "./src/**/**/*.{js,ts,jsx,tsx,html,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,html,mdx}",
  ],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        lime: { 200: "#e1d19a", 300: "#c2ea6b" },
        blue_gray: { 100: "#d9d9d9" },
        gray: { 900: "#1e1e1e" },
        blue: { A200: "#448af4" },
        amber: { A400: "#f4be00" },
        cyan: { 300: "#41e3ee" },
        orange: { 50: "#f4f8d9" },
        teal: { 800: "#236857" },
        black: { 900: "#000000" },
        deep_orange: { 400: "#dd8545" },
        purple: { 500: "#ae18b1" },
        white: { A700: "#ffffff" },
      },
      fontFamily: { jost: "Jost", inter: "Inter" },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};

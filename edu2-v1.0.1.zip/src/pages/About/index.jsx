import React from "react";

import { Button, Img, Line, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";

const AboutPage = () => {
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-jost justify-start mx-auto w-full">
        <div className="flex flex-col items-center w-full">
          <Header className="bg-teal-800 flex sm:flex-col flex-row sm:gap-5 items-center justify-center md:px-5 w-full" />
        </div>
        <Text
          className="md:ml-[0] ml-[90px] mt-[67px] md:text-5xl text-[64px] text-black-900"
          size="txtJostRomanMedium64"
        >
          About Us
        </Text>
        <Text
          className="md:ml-[0] ml-[106px] mt-[50px] md:text-3xl sm:text-[28px] text-[32px] text-black-900"
          size="txtJostRomanRegular32"
        >
          Lorem Ipsum
        </Text>
        <div className="flex flex-col md:gap-10 gap-[71px] items-center mt-[213px] w-full">
          <div className="bg-blue_gray-100 h-[235px] max-w-[1160px] mx-auto md:px-5 w-full"></div>
          <Footer className="bg-teal-800 flex items-center justify-center md:px-5 w-full" />
        </div>
      </div>
    </>
  );
};

export default AboutPage;

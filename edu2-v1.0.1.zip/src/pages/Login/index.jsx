import React from "react";

import { Button, Img, Line, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";

const LoginPage = () => {
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-jost sm:gap-10 md:gap-10 gap-[97px] items-center justify-start mx-auto w-full">
        <Header className="bg-teal-800 flex sm:flex-col flex-row sm:gap-5 items-center justify-center md:px-5 w-full" />
        <div className="bg-blue_gray-100 h-[583px] max-w-[901px] mx-auto md:px-5 w-full"></div>
        <Footer className="bg-teal-800 flex items-center justify-center md:px-5 w-full" />
      </div>
    </>
  );
};

export default LoginPage;

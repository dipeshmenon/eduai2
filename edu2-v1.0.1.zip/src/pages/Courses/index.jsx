import React from "react";

import { Button, Img, Line, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";

const CoursesPage = () => {
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-jost items-center justify-start mx-auto w-full">
        <div className="flex flex-col items-start justify-start w-full">
          <Header className="bg-teal-800 flex sm:flex-col flex-row sm:gap-5 items-center justify-center md:px-5 w-full" />
          <Text
            className="md:ml-[0] ml-[90px] mt-[66px] md:text-5xl text-[64px] text-black-900"
            size="txtJostRomanMedium64"
          >
            Class 9
          </Text>
          <div className="flex md:flex-col flex-row font-inter md:gap-10 items-center justify-between max-w-[1053px] mt-[62px] mx-auto md:px-5 w-full">
            <div className="flex flex-col gap-[57px] items-start justify-start">
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtInterMedium24"
              >
                Unit 1
              </Text>
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtInterMedium24"
              >
                Unit 2
              </Text>
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtInterMedium24"
              >
                Unit 3
              </Text>
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtInterMedium24"
              >
                Unit 4
              </Text>
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtInterMedium24"
              >
                Unit 5
              </Text>
            </div>
            <div className="bg-blue_gray-100 h-[440px] w-3/4"></div>
          </div>
          <Footer className="bg-teal-800 flex font-jost items-center justify-center mt-[115px] md:px-5 w-full" />
        </div>
      </div>
    </>
  );
};

export default CoursesPage;

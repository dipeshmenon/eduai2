import React from "react";

import { Button, Img, Line, List, Text } from "components";
import Header from "components/Header";
import HomeColumnOne from "components/HomeColumnOne";
import HomeColumnwepikexporttwentyThree from "components/HomeColumnwepikexporttwentyThree";
import HomeRowsaturn97113521 from "components/HomeRowsaturn97113521";
import HomeStackeducationthatemOne from "components/HomeStackeducationthatemOne";

const Home1Page = () => {
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-jost items-center justify-end mx-auto w-full">
        <Header className="bg-teal-800 flex sm:flex-col flex-row sm:gap-5 items-center justify-center md:px-5 w-full" />
        <HomeRowsaturn97113521
          className="bg-teal-800 flex md:flex-col flex-row gap-3.5 items-start justify-start pt-[68px] md:px-10 sm:px-5 px-[68px] w-full"
          learningtext={
            <Text className="absolute left-[0] md:text-5xl text-[100px] text-center text-white-A700 top-[0]">
              <span className="text-white-A700 font-jost font-normal">
                Learn On Your{" "}
              </span>
              <span className="text-white-A700 font-jost font-normal">
                <>
                  Time
                  <br />
                </>
              </span>
              <span className="text-white-A700 font-jost font-normal">
                <>
                  From Anywhere In
                  <br />
                  The{" "}
                </>
              </span>
              <span className="text-white-A700 font-jost font-normal">
                World
              </span>
            </Text>
          }
        />
        <HomeColumnOne className="flex flex-col items-center justify-start max-w-[1259px] mt-[68px] mx-auto md:px-5 w-full" />
        <HomeStackeducationthatemOne className="h-[380px] md:h-[411px] max-w-[1040px] mt-[31px] mx-auto md:px-5 relative w-full" />
        <HomeColumnwepikexporttwentyThree className="flex flex-col items-center justify-start mt-[86px] pb-[75px] w-full" />
      </div>
    </>
  );
};

export default Home1Page;

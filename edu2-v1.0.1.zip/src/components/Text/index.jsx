import React from "react";

const sizeClasses = {
  txtJostRomanRegular32: "font-jost font-normal",
  txtJostRomanRegular24: "font-jost font-normal",
  txtJostRomanRegular100: "font-jost font-normal",
  txtJostRomanRegular64: "font-jost font-normal",
  txtJostRomanRegular20: "font-jost font-normal",
  txtJostRomanMedium64WhiteA700: "font-jost font-medium",
  txtInterMedium24: "font-inter font-medium",
  txtJostRomanMedium40: "font-jost font-medium",
  txtJostRomanMedium64: "font-jost font-medium",
  txtJostRomanBold16: "font-bold font-jost",
};

const Text = ({ children, className = "", size, as, ...restProps }) => {
  const Component = as || "p";

  return (
    <Component
      className={`text-left ${className} ${size && sizeClasses[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };

import React from "react";

import { Img, List, Text } from "components";

const HomeColumnOne = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col md:gap-10 gap-[86px] items-center justify-start w-full">
          <div className="flex sm:flex-col flex-row md:gap-10 items-center justify-between w-full">
            <Text
              className="md:text-5xl text-[64px] text-center text-gray-900"
              size="txtJostRomanRegular64"
            >
              {props?.usertext}
            </Text>
            <Text
              className="md:text-3xl sm:text-[28px] text-[32px] text-black-900 text-center"
              size="txtJostRomanRegular32"
            >
              {props?.foreverystudentOne}
            </Text>
          </div>
          <List
            className="sm:flex-col flex-row md:gap-10 gap-[69px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center w-[94%]"
            orientation="horizontal"
          >
            <div className="md:h-[342px] h-[390px] relative w-full">
              <div className="absolute bg-amber-A400 bottom-[0] flex flex-col h-[342px] inset-x-[0] items-center justify-end mx-auto p-[25px] sm:px-5 rounded-[50%] w-[342px]">
                <Text
                  className="mb-[58px] mt-24 text-black-900 text-center text-xl w-full"
                  size="txtJostRomanRegular20"
                >
                  {props?.discoverthemagiOne}
                </Text>
              </div>
              <div className="absolute bg-purple-500 flex flex-col h-[101px] inset-x-[0] items-center justify-start mx-auto p-[26px] sm:px-5 rounded-[50px] top-[0] w-[101px]">
                <Img
                  className="h-[49px] md:h-auto object-cover w-[49px]"
                  src="images/img_ruler87197081.png"
                  alt="ruler87197081"
                />
              </div>
            </div>
            <div className="h-[393px] relative w-full">
              <div className="bg-cyan-300 flex flex-col h-[342px] items-center justify-end mb-[undefinedpx] mt-auto mx-auto p-[25px] sm:px-5 rounded-[50%] w-[342px] z-[1]">
                <Text
                  className="mb-[25px] mt-[63px] text-black-900 text-center text-xl w-full"
                  size="txtJostRomanRegular20"
                >
                  {props?.description}
                </Text>
              </div>
              <div className="bg-blue-A200 flex flex-col h-[101px] items-center justify-start mb-[-50px] mx-auto p-[26px] sm:px-5 rounded-[50px] w-[101px] z-[1]">
                <Img
                  className="h-[49px] md:h-auto object-cover w-[49px]"
                  src="images/img_science2022299.png"
                  alt="science2022299"
                />
              </div>
            </div>
            <div className="h-[393px] relative w-full">
              <div className="bg-deep_orange-400 flex flex-col h-[342px] items-center justify-end mb-[undefinedpx] mt-auto mx-auto p-[22px] sm:px-5 rounded-[50%] w-[342px] z-[1]">
                <Text
                  className="mb-6 mt-[70px] text-black-900 text-center text-xl w-[98%] sm:w-full"
                  size="txtJostRomanRegular20"
                >
                  {props?.description1}
                </Text>
              </div>
              <div className="bg-lime-300 flex flex-col h-[101px] items-end justify-start mb-[-50px] mx-auto p-[23px] sm:px-5 rounded-[50px] w-[101px] z-[1]">
                <Img
                  className="h-[49px] md:h-auto my-[3px] object-cover w-[49px]"
                  src="images/img_creativewriting1973807.png"
                  alt="creativewriting"
                />
              </div>
            </div>
          </List>
        </div>
      </div>
    </>
  );
};

HomeColumnOne.defaultProps = {
  usertext: "Become The Best Version Of You",
  foreverystudentOne: "For Every Student, In Every Course, Real Results.",
  discoverthemagiOne:
    "Discover the Magic of Math Unleash the potential of numbers and equations on your educational journey.",
  description: (
    <>
      Explore the Wonders of Science Delve into the mysteries of the natural
      world and the universe, uncovering the secrets of life, matter, and the
      cosmos. Let&#39;s embark on a scientific voyage together!
    </>
  ),
  description1: (
    <>
      Elevate Your Content with AI - Experience the future of writing as our AI
      technology assists you in creating engaging and impactful content.
      Let&#39;s write together, the smart way!
    </>
  ),
};

export default HomeColumnOne;

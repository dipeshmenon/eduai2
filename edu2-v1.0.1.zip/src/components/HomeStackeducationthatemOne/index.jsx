import React from "react";

import { Img, Text } from "components";

const HomeStackeducationthatemOne = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="absolute bg-orange-50 bottom-[0] flex flex-col gap-2 inset-x-[0] items-start justify-start mx-auto p-8 sm:px-5 rounded-[20px] w-full">
          <Text
            className="md:ml-[0] ml-[15px] sm:text-4xl md:text-[38px] text-[40px] text-black-900 w-[48%] sm:w-full"
            size="txtJostRomanMedium40"
          >
            {props?.educationtext}
          </Text>
          <Text
            className="mb-2 md:ml-[0] ml-[15px] text-2xl md:text-[22px] text-black-900 sm:text-xl w-[54%] sm:w-full"
            size="txtJostRomanRegular24"
          >
            {props?.superchargetext}
          </Text>
        </div>
        <Img
          className="absolute h-[380px] inset-y-[0] my-auto object-cover right-[5%] w-[21%]"
          src="images/img_wepikexport20_380x209.png"
          alt="wepikexportTwenty_Two"
        />
      </div>
    </>
  );
};

HomeStackeducationthatemOne.defaultProps = {
  educationtext: (
    <>
      Education That
      <br />
      Empowers You
    </>
  ),
  superchargetext:
    "Supercharge Your Work - Boost productivity with our AI tools. Write, summarize, chat, and code more efficiently.",
};

export default HomeStackeducationthatemOne;

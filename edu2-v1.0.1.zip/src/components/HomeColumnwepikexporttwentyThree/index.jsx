import React from "react";

import { useNavigate } from "react-router-dom";

import { Button, Img, Line, Text } from "components";

const HomeColumnwepikexporttwentyThree = (props) => {
  const navigate = useNavigate();

  return (
    <>
      <div className={props.className}>
        <div className="sm:h-[563px] h-[564px] md:h-[795px] relative w-full">
          <div className="absolute bg-teal-800 flex flex-col h-full inset-[0] items-center justify-center m-auto p-[115px] md:px-10 sm:px-5 w-full">
            <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between mt-20 w-[86%] md:w-full">
              <div className="bg-cyan-300 h-[250px] md:mt-0 mt-[3px] rounded-[15px] w-[33%]"></div>
              <div className="flex flex-col gap-[39px] items-center justify-start">
                <Text
                  className="md:text-5xl text-[64px] text-center text-white-A700"
                  size="txtJostRomanMedium64WhiteA700"
                >
                  {props?.becomeanexpert}
                </Text>
                <Button
                  className="!text-teal-800 cursor-pointer font-jost font-medium leading-[normal] min-w-[229px] md:text-3xl sm:text-[28px] text-[32px] text-center"
                  shape="round"
                  color="amber_A400"
                  size="xs"
                  variant="fill"
                >
                  {props?.startToday}
                </Button>
              </div>
            </div>
          </div>
          <Img
            className="absolute h-[380px] left-[0] object-cover top-[12%] w-[36%]"
            src="images/img_wepikexport20_380x505.png"
            alt="wepikexportTwenty_Three"
          />
        </div>
        <div className="bg-teal-800 flex flex-col items-center justify-start p-[22px] sm:px-5 w-full">
          <div className="flex flex-col gap-[31px] items-center justify-start mb-[33px] w-[91%] md:w-full">
            <Line className="bg-white-A700 h-px w-full" />
            <div className="flex sm:flex-col flex-row sm:gap-5 items-center justify-center w-[38%] md:w-full">
              <Text
                className="common-pointer text-base text-white-A700"
                size="txtJostRomanBold16"
                onClick={() => navigate("/home1")}
              >
                {props?.hometext}
              </Text>
              <Text
                className="common-pointer sm:ml-[0] ml-[93px] text-base text-white-A700"
                size="txtJostRomanBold16"
                onClick={() => navigate("/courses")}
              >
                {props?.coursestext}
              </Text>
              <Text
                className="sm:ml-[0] ml-[94px] text-base text-white-A700"
                size="txtJostRomanBold16"
              >
                {props?.toolstext}
              </Text>
              <Text
                className="common-pointer sm:ml-[0] ml-[94px] text-base text-white-A700"
                size="txtJostRomanBold16"
                onClick={() => navigate("/about")}
              >
                {props?.abouttext}
              </Text>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

HomeColumnwepikexporttwentyThree.defaultProps = {
  becomeanexpert: "Become An Expert",
  startToday: "Start Today",
  hometext: "Home",
  coursestext: "Courses",
  toolstext: "Tools",
  abouttext: "About",
};

export default HomeColumnwepikexporttwentyThree;

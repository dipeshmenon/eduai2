import React from "react";

import { useNavigate } from "react-router-dom";

import { Button, Img, Text } from "components";

const Header = (props) => {
  const navigate = useNavigate();

  return (
    <>
      <header className={props.className}>
        <Img
          className="common-pointer h-[65px] md:h-auto ml-16 sm:ml-[0] sm:mt-0 my-[23px] object-cover w-[10%] sm:w-full"
          src="images/img_imageremovebgpreview.png"
          alt="imageremovebgpr"
          onClick={() => navigate("/home1")}
        />
        <Text
          className="common-pointer mb-[41px] sm:ml-[0] ml-[335px] sm:mt-0 mt-[46px] text-base text-white-A700"
          size="txtJostRomanBold16"
          onClick={() => navigate("/home1")}
        >
          Home
        </Text>
        <Text
          className="common-pointer mb-[41px] sm:ml-[0] ml-[39px] sm:mt-0 mt-[46px] text-base text-white-A700"
          size="txtJostRomanBold16"
          onClick={() => navigate("/courses")}
        >
          Courses
        </Text>
        <Text
          className="mb-[42px] sm:ml-[0] ml-[34px] sm:mt-0 mt-[45px] text-base text-white-A700"
          size="txtJostRomanBold16"
        >
          Tools
        </Text>
        <Text
          className="common-pointer mb-[42px] sm:ml-[0] ml-[42px] sm:mt-0 mt-[45px] text-base text-white-A700"
          size="txtJostRomanBold16"
          onClick={() => navigate("/about")}
        >
          About
        </Text>
        <Text
          className="common-pointer mb-[39px] sm:ml-[0] ml-[371px] sm:mt-0 mt-12 text-base text-white-A700"
          size="txtJostRomanBold16"
          onClick={() => navigate("/login")}
        >
          Login
        </Text>
        <Button
          className="!text-teal-800 cursor-pointer font-bold font-jost leading-[normal] mb-[35px] min-w-[103px] sm:ml-[0] ml-[30px] mr-12 sm:mt-0 mt-10 rounded-[18px] text-base text-center"
          color="amber_A400"
          size="xs"
          variant="fill"
        >
          Sign up
        </Button>
      </header>
    </>
  );
};

Header.defaultProps = {};

export default Header;

import React from "react";

import { Line, Text } from "components";

const Footer = (props) => {
  return (
    <>
      <footer className={props.className}>
        <div className="flex flex-col items-center justify-center mb-[55px] mt-[22px] mx-auto w-[88%]">
          <div className="flex flex-col gap-[31px] items-center justify-center w-full">
            <Line className="bg-white-A700 h-px w-full" />
            <ul className="flex sm:flex-col flex-row sm:gap-5 items-center justify-center w-[38%] md:w-full common-column-list">
              <li>
                <Text
                  className="text-base text-white-A700"
                  size="txtJostRomanBold16"
                >
                  Home
                </Text>
              </li>
              <li>
                <Text
                  className="sm:ml-[0] ml-[93px] text-base text-white-A700"
                  size="txtJostRomanBold16"
                >
                  Courses
                </Text>
              </li>
              <li>
                <Text
                  className="sm:ml-[0] ml-[94px] text-base text-white-A700"
                  size="txtJostRomanBold16"
                >
                  Tools
                </Text>
              </li>
              <li>
                <Text
                  className="sm:ml-[0] ml-[94px] text-base text-white-A700"
                  size="txtJostRomanBold16"
                >
                  About
                </Text>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </>
  );
};

Footer.defaultProps = {};

export default Footer;

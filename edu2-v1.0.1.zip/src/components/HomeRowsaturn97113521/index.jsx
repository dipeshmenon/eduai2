import React from "react";

import { Img, Text } from "components";

const HomeRowsaturn97113521 = (props) => {
  return (
    <>
      <div className={props.className}>
        <Img
          className="h-[49px] md:h-auto md:mt-0 mt-[269px] object-cover w-[49px]"
          src="images/img_saturn97113521.png"
          alt="saturn97113521"
        />
        <div className="md:h-[479px] h-[695px] md:mt-0 mt-1.5 relative w-[93%] md:w-full">
          <div className="absolute md:h-[479px] h-[695px] inset-y-[0] my-auto right-[0] w-[86%] md:w-full">
            {props?.learningtext}
            <div className="absolute bottom-[0] h-[359px] right-[0] w-[31%]">
              <div className="absolute flex flex-col h-max inset-[0] items-center justify-center m-auto w-full">
                <div className="flex flex-col gap-[13px] items-end justify-start w-full">
                  <div className="bg-cyan-300 h-[86px] rounded-[15px] w-[55%]"></div>
                  <div className="flex flex-col gap-[13px] items-center justify-start w-full">
                    <div className="bg-cyan-300 h-[86px] rounded-[15px] w-full"></div>
                    <div className="bg-cyan-300 h-[86px] rounded-[15px] w-full"></div>
                  </div>
                </div>
              </div>
              <Img
                className="absolute h-[359px] inset-[0] justify-center m-auto object-cover w-[84%]"
                src="images/img_wepikexport20.png"
                alt="wepikexportTwenty"
              />
            </div>
          </div>
          <div className="absolute bottom-[7%] flex h-[358px] justify-end left-[2%] w-1/5">
            <div className="bg-lime-200 h-[265px] mt-auto mx-auto rounded-[20px] w-[96%]"></div>
            <Img
              className="absolute h-[358px] inset-[0] justify-center m-auto object-cover w-full"
              src="images/img_wepikexport20_358x231.png"
              alt="wepikexportTwenty_One"
            />
          </div>
          <div className="absolute bottom-[18%] flex flex-row gap-[227px] items-start justify-center left-[31%] w-[30%]">
            <Img
              className="h-[62px] md:h-auto mt-[7px] object-cover w-[62px]"
              src="images/img_essay32532671.png"
              alt="essay32532671"
            />
            <Img
              className="h-[59px] md:h-auto object-cover w-[18%]"
              src="images/img_lightbulb3176298.png"
              alt="lightbulb317629"
            />
          </div>
          <Img
            className="absolute h-[61px] object-cover right-[20%] top-[42%] w-[61px]"
            src="images/img_openbook2702134.png"
            alt="openbook2702134"
          />
          <Img
            className="absolute h-[66px] left-[0] object-cover top-[7%] w-[66px]"
            src="images/img_beaker38706581.png"
            alt="beaker38706581"
          />
          <Img
            className="absolute h-[49px] object-cover right-[0] top-[8%] w-[49px]"
            src="images/img_star6164901.png"
            alt="star6164901"
          />
        </div>
      </div>
    </>
  );
};

HomeRowsaturn97113521.defaultProps = {
  learningtext: (
    <Text
      className="absolute left-[0] md:text-5xl text-[100px] text-center text-white-A700 top-[0] w-[83%] sm:w-full"
      size="txtJostRomanRegular100"
    >
      <span className="text-white-A700 font-jost font-normal">
        Learn On Your{" "}
      </span>
      <span className="text-white-A700 font-jost font-normal">
        <>
          Time
          <br />
        </>
      </span>
      <span className="text-white-A700 font-jost font-normal">
        <>
          From Anywhere In
          <br />
          The{" "}
        </>
      </span>
      <span className="text-white-A700 font-jost font-normal">World</span>
    </Text>
  ),
};

export default HomeRowsaturn97113521;
